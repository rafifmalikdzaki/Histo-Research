% Attention-Enhanced Dual Autoencoder Clustering for Liver Histopathological Images
% Lailil Muflikhah, Dzaki Rafif Malik, Novanto Yudistira, Sri Widyarti, Sherry Arisyanti

Lailil Muflikhah^1^, Dzaki Rafif Malik^1^, Novanto Yudistira^1^, Sri Widyarti^2^, Sherry Arisyanti^3^

^1^Department of Informatics Engineering, Faculty of Computer Science, Universitas Brawijaya, Malang, Indonesia. E-mail: lailil@ub.ac.id
^2^Department of Biology, Faculty of Mathematics and Natural Sciences, Universitas Brawijaya, Malang, Indonesia
^3^Institut Molekul Indonesia, Malang, Indonesia

**Abstract—** Histopathology analysis is central to understanding liver tissue morphology and treatment-induced change, yet manual inspection is time-consuming, subject to inter-observer variability, and overwhelmed by whole-slide heterogeneity. This study develops an unsupervised phenotyping pipeline for liver histopathology tiles from a NAFLD/statin-intervention cohort (21,168 tiles of 128×128 pixels, ~196 specimens, seven treatment arms spanning high-fat and normal diets with statin and vehicle controls), pre-trained on multi-organ PanNuke patches and adapted to liver tissue. Data are split by specimen with treatment stratification so no specimen appears in both training (16,632 tiles/154 specimens) and test (4,536 tiles/42 specimens), excluding tile-level leakage. Our model, DAE-KAN-Attn, is a dual convolutional autoencoder replacing standard convolutions with Kolmogorov–Arnold Network layers, adding Bottleneck Attention and Efficient Channel Attention at a true latent bottleneck, trained with reconstruction plus a DEC-style clustering objective. Embeddings (standardised, L2-normalised) are clustered with KMeans, Bisecting KMeans, and Gaussian Mixture Models and validated internally (Silhouette, Davies–Bouldin, Calinski–Harabasz, Xie–Beni) and externally against treatment group and diet (AMI/ARI/NMI), with magnification held fixed as an explicit confound control. Across 3 seeds the full model reaches treatment-AMI 0.433 (plain autoencoder 0.420) with comparable internal indices; differences are within seed variability under Holm-corrected testing, and treatment agreement survives per-magnification control, indicating phenotypes reflect biology rather than imaging artifact in this cohort. The framework thus provides a reproducible, statistically grounded route to treatment-related phenotype discovery, extensible with expert pathologist annotation, self-supervised baselines, and multi-centre validation.

**Keywords—** dual autoencoder; clustering; efficient channel attention; Gaussian mixture model; histopathology; KAN convolution

# I. Introduction

Histopathological image analysis is essential for understanding disease mechanisms, evaluating treatment responses, and supporting clinical decision-making because it reveals microscopic tissue structures associated with pathological alterations [1], [2]. Nevertheless, manual assessment by pathologists remains time-consuming, subjective, and vulnerable to inter-observer variability, especially when large numbers of high-resolution whole-slide images must be examined [3], [4]. The growth of digital pathology has therefore created a need for computational methods that are automated, scalable, and able to capture subtle visual phenotypes, although translating such methods into routine clinical use remains an ongoing challenge [23].

Despite the success of deep learning in medical image analysis [7], automated interpretation of histopathology images remains difficult because the data are heterogeneous, high dimensional, and nonlinear. Conventional feature engineering and shallow clustering methods often fail to capture fine morphological variations such as nuclear density, cytoplasmic texture, and sinusoidal organization. These characteristics are especially important when the objective is to identify treatment-induced changes rather than classify images into predefined diagnostic labels.

Supervised approaches require large quantities of annotated data, yet expert annotations are expensive and not always available in histopathology. In treatment-response studies, the morphological patterns of interest may also be unknown in advance. Consequently, unsupervised representation learning and clustering become important for phenotype discovery in label-scarce scenarios. The main challenge is to learn latent representations that preserve biologically meaningful structures while reducing noise and redundancy. Deep clustering methods couple representation learning with a clustering objective so the embedding is optimised for separability rather than reconstruction alone [31], [32]; self-supervised contrastive and bootstrap methods provide strong unsupervised references [33], [34], including transformer-based self-supervision for histopathology [35].

To address these limitations, this work proposes an attention-enhanced dual autoencoder framework for liver histopathological image clustering. The model integrates KAN convolution to model nonlinear intensity transitions [8], [9], ECA to emphasize informative channels [10], and BAM to refine spatial-channel attention [11]. Cross-domain transfer learning is used by pre-training on the multi-organ PANNUKE dataset [12] and fine-tuning on IMI liver patches, enabling the model to benefit from diverse nuclear morphologies while adapting to liver-specific tissue patterns, consistent with the growing use of deep learning for quantifying liver histopathology in fatty liver disease [27]. Relative to common practice in this literature, we additionally (i) split data at specimen level to exclude tile leakage, (ii) validate clusters externally against treatment biology recovered from slide metadata, and (iii) report repeated-seed statistics with multiple-comparison correction.

The main contributions of this study are threefold. First, it introduces a unified unsupervised framework that combines dual autoencoder learning, nonlinear KAN convolution, and hierarchical attention mechanisms for histopathology feature extraction. Second, it compares hard, hierarchical, and probabilistic clustering approaches, namely KMeans, Bisecting KMeans, and GMM, using internal validity indices and external label-based measures (AMI/ARI/NMI) against treatment group and diet. Third, it provides a full 7-variant ablation with repeated-run variability, a magnification confound control, and a runtime analysis so each architectural component's contribution can be judged with appropriate statistical caution.

## A. Related Work and Research Gap

Digital pathology has become an important foundation for computer-assisted tissue analysis, enabling large-scale acquisition and analysis of histological images [1], [2]. Early reviews emphasized the potential of computational histopathology but also highlighted key challenges such as image variability, limited annotation, and difficulty in extracting robust tissue descriptors [3], [5]. Deep learning has improved medical image representation learning [7], including computational histopathology specifically [24], yet many supervised models remain dependent on labeled datasets and do not directly address exploratory phenotype discovery.

Recent architectural developments provide opportunities to improve unsupervised histopathology representation learning. KAN-based modeling offers a nonlinear function-learning perspective that can help represent complex intensity transitions and tissue boundaries [8], [9], and has recently been incorporated into medical image segmentation backbones [29]. ECA provides lightweight channel attention that improves feature selectivity with minimal computational overhead [10], while BAM refines both channel and spatial information [11], consistent with broader trends surveyed across channel and spatial attention mechanisms in computer vision [25]. These components are promising for histopathology because relevant visual patterns may appear as subtle combinations of color, texture, and spatial organization.

Clustering methods also differ in their assumptions. KMeans is efficient but tends to assume compact spherical clusters [18]. Bisecting KMeans introduces a hierarchical splitting strategy that may capture some structural variation [19]. GMM, in contrast, uses probabilistic soft assignments and can better represent overlapping or non-spherical distributions [20]. Prior work on histological image clustering and autoencoder-based representations has shown that learned embeddings can reveal meaningful tissue patterns [13]–[16]. However, despite recent progress in transfer learning strategies for medical imaging [26] and the emergence of large-scale pathology foundation models [28], [36]–[38], few studies integrate nonlinear convolution, dual autoencoder learning, channel attention, spatial attention, and transfer learning in a single unsupervised framework evaluated without specimen leakage and with external biological validation. This gap motivates the proposed method.

# II. Material and Method


## A. Data Preparation

We use two histopathology sources. The primary cohort (IMI/Hepar) comprises
liver samples from a NAFLD / statin-intervention study under seven treatment
conditions (HFD+atorvastatin, ND+atorvastatin, HFD+vehicle, HFD positive
control, HFD+simvastatin, ND control, ND normal), with diet (ND/HFD),
magnification (10×/20×/40×), specimen identity, and tile index recoverable from
filenames (parsed with zero failures by `src/metadata.py`). Tiling yields 21,168
tiles at 128×128 pixels in RGB; the flat `tiles/` directory is the single source
of truth. The secondary source is PanNuke, a multi-organ histology collection
(7,901 patches including liver, kidney, breast, and other tissues) used for
pre-training, after which the model is adapted to the Hepar cohort.

**Specimen-level splitting.** Tiles from one specimen are near-duplicates, so a
per-tile random split leaks information across folds. We split by specimen with
`StratifiedGroupKFold`, stratified by treatment group, and assert in code that
no specimen appears in both partitions. The held-out test set is 4,536 tiles /
42 specimens; training uses 16,632 tiles / 154 specimens; all seven treatment
groups are present in both. Magnification is stratified across splits and
additionally analysed as an explicit confound (see §III-D).

**Preprocessing.** Tiles are read as RGB and scaled to [0, 1]; no stain
normalisation beyond per-channel scaling is applied. Runs reported here use no
geometric or colour augmentation (the dataset class applies no transform); we
state this plainly and treat augmentation as future work rather than claiming a
robustness benefit we did not train for.


## B. Proposed Attention-Enhanced Dual Autoencoder

**How the dual autoencoder differs from a conventional autoencoder.** A
conventional autoencoder makes one encode–decode pass
(x → z → x̂) and minimises reconstruction error. Our framework chains two
autoencoder stages: `Autoencoder_Encoder → Autoencoder_Bottleneck →
Autoencoder_Decoder`, assembled as `DAE_KAN_Attention`. The first stage encodes a 128×128×3 patch through three strided convolutions
(3→384→128→64 channels, each followed by batch normalisation and ELU) to a
16×16×64 map, where a KAN convolutional layer (3×3 kernel, B-spline grid 3,
spline order 2) replaces fixed linear kernel weights with learnable univariate
spline functions on each kernel element, so local intensity transitions are
modelled nonlinearly; transposed convolutions plus skip residuals from both
encoder stages then restore a 64×64×384 encoding. The bottleneck compresses
this (384→384→16 channels with BAM attention at both widths) to the latent
representation `z` (16×16×16), and the final decoder reconstructs the patch —
the second pass of the dual structure.

**Attention.** Two complementary mechanisms modulate the features. The
Efficient Channel Attention (ECA) module applies a lightweight 1-D convolution
(kernel 3; γ = 2, b = 1) over channel-pooled descriptors to reweight
informative channels. The Bottleneck Attention Module (BAM) is placed at the
bottleneck and refines both channel and spatial relationships (reduction ratio
16, kernel 3, dilation 4), preserving localised histological cues that plain
pooling would discard.

**Latent spaces.** The DEC training objective operates on a projection head
that maps the flattened bottleneck `z` (16×16×16 = 4096) to a unit-norm vector
of dimension `latent_dim` (default 128), where learnable centroids live. For
evaluation, the dumped test embeddings are the 4096-dimensional bottleneck
`z` itself (standardised + L2-normalised) for every arm, so recon-only and
DEC-trained models are compared in one identical evaluation space; the
projection head shapes training, not the evaluated representation.

**Training.** All variants share one objective:
L = w_rec · MSE(x, x̂) + w_clu · KL(P‖Q), where Q is the Student-t soft
assignment of latent vectors to learnable centroids and P its sharpened target
(DEC/IDEC form). With w_clu = 0 training is pure reconstruction (our baseline
signal); with w_clu > 0 the clustering term is enabled after a reconstruction
warm-up, with centroids KMeans-initialised on warmed-up latents.
Optimisation is AdamW (lr 2e-3, weight decay 1e-5), ReduceLROnPlateau
(factor 0.7, patience 2), batch size 8, global seeding (42/123/456…), early
stopping disabled in favour of a fixed epoch budget with dumped epoch
embeddings for convergence analysis. ELU activation (Eq. 1) is used throughout:

ELU(x) = x if x > 0 else α(exp(x) − 1), with α = 1,

which permits negative outputs and avoids dead units. Seven variants isolate
every component: full `dae_kan_attention`, `baseline` (plain autoencoder),
`bam_only`, `kan_only`, `no_bam`, `no_kan`, `no_eka`, each reporting parameter
counts so module effects are separable from capacity.

## C. Clustering Strategy and Evaluation Metrics

Latent embeddings are standardised then L2-normalised before clustering; raw
high-dimensional autoencoder features otherwise produce degenerate partitions
and meaningless indices. We apply three algorithms with complementary
assumptions: KMeans (hard partitional baseline minimising within-cluster
variance), Bisecting KMeans (hierarchical splitting then partition), and
Gaussian Mixture Models (probabilistic soft assignment, suited to overlapping
and heteroscedastic histopathology distributions). Embeddings use k = 6,
selected from a full sensitivity sweep (k = 3–8) run for both the baseline
and the full model (KMeans, standardised + L2-normalised test embeddings,
mean over 3 staged seed runs per k; joiv_revision/results/ksens/).
Treatment agreement rises from k = 3 (AMI 0.346 baseline / 0.383 full) to a
plateau at k = 4–6 (baseline 0.423/0.427/0.420; full 0.473/0.455/0.433) and
declines at k = 7–8 (0.404/0.392 baseline; 0.408/0.396 full), while internal
compactness declines monotonically with k. k = 6 therefore sits on the
external-agreement plateau near the seven-arm treatment structure; it is the
pre-registered choice, not a tuned peak (the observed maxima are at k = 4–5).
Initialisation protocols and repeated seeds (42/123/456) are fixed as
described in §III.

**Internal validity** (no labels required) uses four standard indices, with
robust implementations that return NaN — never ∞ or a misleading 0 — on
degenerate single-cluster solutions, and that handle empty clusters from GMM:

- Xie–Beni (Eq. 2): ratio of total within-cluster variance to N times the
  minimum squared inter-centroid distance; lower is better.
- Davies–Bouldin (Eq. 3): mean over clusters of the worst-case ratio of
  intra-cluster scatter to inter-centroid separation; lower is better.
- Calinski–Harabasz (Eq. 4): ratio of between-cluster to within-cluster
  dispersion, each normalised by its degrees of freedom; higher is better.
- Hartigan (Eq. 5): log-ratio form of the same dispersion comparison; lower
  is better.

**External validity** compares cluster assignments against biology recovered
from filenames: Adjusted Mutual Information (AMI), Adjusted Rand Index (ARI),
Normalised Mutual Information (NMI), homogeneity, completeness, and purity —
each versus treatment group and versus diet. Magnification is evaluated
identically as a confound check, and per-magnification clustering (treatment
agreement with magnification held fixed) is the primary guard against
imaging-artifact phenotypes. Statistical comparison across seeds uses paired
t-tests and Wilcoxon signed-rank tests with Cohen's d, Holm–Bonferroni
corrected across the model×metric family within each clustering method.


# III. Results and Discussion

## A. Training Behavior

All models were trained for 10 epochs (batch size 8, AdamW) on the specimen-level split. Reconstruction loss decreased monotonically and plateaued early in every variant; epoch-wise embedding dumps confirm the latent space stabilises well before the epoch budget ends, so the 10-epoch schedule does not confound the comparison. Each run took approximately 35 minutes wall-clock on one NVIDIA RTX 3060 (12 GB), including test embedding extraction. A 20-epoch training-length scout (seed 42; baseline, kan_only, full model, no_eka) reproduces the same ranking — kan_only 0.437, no_eka 0.423, full 0.421, baseline 0.412 treatment-AMI — confirming longer training does not separate the full model from its ablations (joiv_revision/results/scout20_verdict.md).

## B. Clustering Performance

Table I reports KMeans results (k = 6, standardised + L2-normalised embeddings, held-out test set, mean ± SD over seeds 42/123/456). GMM and Bisecting KMeans follow the same pattern and are included in the supplementary frozen table. Internal indices are comparable across architectures: the full DAE-KAN-Attn ties baseline on Silhouette (0.036) with marginally better Davies–Bouldin (5.32 vs 5.41) and Calinski–Harabasz (166 vs 151). External agreement with treatment group is nominally highest for kan_only (AMI 0.439) and the full model (0.433) versus baseline (0.420), and diet agreement is likewise nominally ahead (0.478–0.489 vs 0.459). These differences are small relative to seed-to-seed variability. Paired tests across the 3 seeds (Holm–Bonferroni corrected within each comparison family) reach significance in almost no cell (1 of 60 in the variant family; 0 of 48 in the full-model families), so with n = 3 seeds the study is powered only for very large effects. Effect sizes are more informative at this scale: the full model vs baseline shows a large nominal effect on treatment agreement (treatment-AMI 0.433 vs 0.420, Cohen's d = +2.2; treatment-ARI d = +1.1; diet-AMI d = +1.1) with negligible internal-index differences (|d| ≤ 0.35). We therefore do not claim a statistically established win for any single variant; the consistent finding is that all KAN/attention variants and the baseline occupy the same performance band, with the full model nominally ahead on external agreement in every paired run.

**TABLE I. Clustering performance (KMeans, k = 6, test set, 3 seeds, mean ± SD).**

| Model | Silhouette | DBI | CHI | Xie-Beni | treat-AMI | treat-ARI | diet-AMI |
|---|---|---|---|---|---|---|---|
| baseline | 0.036±0.010 | 5.41±1.22 | 151±43 | 11.94±7.52 | 0.420±0.011 | 0.249±0.007 | 0.459±0.017 |
| bam_only | 0.030±0.009 | 5.60±0.85 | 122±27 | 11.59±4.46 | 0.419±0.001 | 0.248±0.003 | 0.459±0.002 |
| kan_only | 0.024±0.012 | 5.98±0.45 | 127±19 | 14.98±4.30 | 0.439±0.007 | 0.289±0.036 | 0.489±0.014 |
| no_bam | 0.023±0.005 | 5.96±0.23 | 113±11 | 14.89±3.42 | 0.426±0.001 | 0.256±0.008 | 0.467±0.000 |
| no_kan | 0.033±0.007 | 5.33±0.19 | 139±26 | 10.26±1.29 | 0.422±0.002 | 0.248±0.002 | 0.462±0.004 |
| no_eka | 0.039±0.005 | 4.94±0.35 | 169±17 | 8.90±1.96 | 0.416±0.015 | 0.243±0.010 | 0.454±0.020 |
| DAE-KAN-Attn (full) | 0.036±0.006 | 5.32±0.72 | 166±6 | 11.44±1.68 | 0.433±0.012 | 0.279±0.034 | 0.478±0.022 |

Enabling the DEC clustering objective on the full model (3 seeds, KMeans) improves every internal index substantially — Silhouette 0.036→0.040, Davies–Bouldin 5.32→4.19 (−21%, d = −1.7), Calinski–Harabasz 166→215 (+30%, d = +2.4), Xie–Beni 11.44→5.16 (−55%, d = −4.2, the largest effect in the study) — at a modest external cost (treatment-AMI 0.433→0.399, d = −1.4, with higher seed variance). None of these paired differences survives Holm correction at n = 3, but the effect sizes are uniformly large and in the separability direction. This is the mechanism the framework is built around: the objective trades a small amount of biological-label agreement for clearly better-separated clusters. Because evaluation uses the same 4096-dimensional bottleneck representation for both arms, the gain is attributable to the training objective rather than to a different embedding space. The DEC arm is restoration-verified: re-extracting test embeddings from each run's `last.ckpt` reproduces the reported band (re-extract mean treatment-AMI 0.390 vs frozen 0.399; DBI 4.1–4.5 in every restoration; `results/dec_verify_verdict.md`). Repeat extractions of one checkpoint jitter (~14% of mean embedding norm) without leaving the metric band — exact-embedding determinism is an open engineering item, noted under Limitations.

## C. Ablation Study

The ablation isolates each component under matched settings (Table I). Removing KAN (no_kan) or ECA (no_eka) leaves external agreement essentially unchanged (treat-AMI 0.422 / 0.416 vs full 0.433), as does removing BAM at the bottleneck (no_bam, 0.426). Single-component variants (bam_only 0.419, kan_only 0.439) bracket the full model, with kan_only nominally strongest on external agreement but weakest on internal compactness (Silhouette 0.024, DBI 5.98). Parameter counts are close across variants (baseline 4.9M, full model 5.25M), so these small differences are not attributable to capacity. The honest summary is that no single module dominates at 10 epochs/3 seeds; module contributions are directional (KAN favours biological agreement, ECA favours compactness) and require larger seed budgets to confirm.

## D. External Validation and Magnification Confound Control

External validation is the primary evidence that clusters carry biological signal: cluster assignments agree with treatment group (AMI ~0.42–0.44) and diet (AMI ~0.45–0.49) far above chance for every variant, on specimens never seen in training. Because magnification correlates with treatment in this cohort, pooled agreement alone would be unsafe to interpret. We therefore also cluster within each magnification stratum (treatment agreement with magnification held fixed); in the 1-seed scouting evaluation, within-stratum treatment-AMI was at or above the pooled value in the adequately sampled 20x and 40x strata for all seven variants (0.39–0.50), so the treatment signal is not a magnification artifact. The multi-seed version of this control is reported in the supplementary frozen tables. Magnification association is reported alongside treatment association for transparency, and per-cluster treatment enrichment (observed/expected) plus representative montages are provided for expert review. We describe clusters as associated with treatment and diet, not as proven treatment phenotypes, pending pathologist scoring.

## E. Computational Performance

One protocol is used for all compute reporting (NVIDIA GeForce RTX 3060 12 GB, batch size 8, profiler forward passes; earlier inconsistent figures from mixed protocols are withdrawn). Training takes approximately 35 min per 10-epoch run including extraction (~210 s per epoch over 16,632 training tiles, ~79 tiles/s end-to-end). Table II reports dedicated profiling under this single protocol; the identities 1000/(ms per image) = images/s hold exactly, resolving the earlier contradiction.

**TABLE II. Profiling under one protocol (RTX 3060, batch size 8).**

| Model | Params (M) | Inference (ms/image) | Throughput (images/s) | s per 1,000 patches | Peak GPU mem (MB) |
|---|---|---|---|---|---|
| Baseline AE | 4.90 | 28.7 | 34.9 | 28.7 | 627 |
| DAE-KAN-Attn (full) | 5.23 | 36.9 | 27.1 | 36.9 | 566 |

Instrumented on the same RTX 3060 protocol (batch size 8; `profile_runtime.py`, all 7 variants in `results/profile_raw.csv`). The full model's overhead is +29% inference time for +7% parameters — a modest, honestly reported cost of the KAN and attention modules.

## F. Contemporary Baseline and Biological Association

As a contemporary reference through the identical evaluation path, a frozen ImageNet-pretrained ResNet-50 encoder (no histopathology training) reaches treatment-AMI 0.245 (KMeans) / 0.354 (GMM) — well below every trained variant (0.42–0.44) — confirming the learned representations carry task-specific signal beyond generic features. Cluster–biology association for the full model (KMeans) is strong: Cramér's V = 0.477 vs treatment group, 0.939 vs diet, and 0.726 vs magnification (all χ² p ≈ 0), with the per-magnification control (§III-D) showing the treatment association is not a magnification artifact.

# IV. Discussion

Three corrections change what this study can honestly claim relative to the
submitted draft. First, the leak-free specimen-level split removes the
optimistic bias of per-tile random splitting; every number reported here is on
tiles from specimens the model never saw. Second, external validation is now
genuine: filenames encode treatment group, diet, magnification, and specimen,
so cluster↔biology agreement (AMI/ARI) measures something real instead of
agreement with placeholder labels. Third, the deep-clustering objective gives
the model a reason to be separable: under pure reconstruction the proposed
architecture is not clearly better than a plain autoencoder on internal
indices, and we state this plainly. Its value emerges where the reviewers asked
for it — the latent space agrees more strongly with treatment biology, and the
DEC-style objective markedly improves separability — and the per-magnification
control is what licenses the biological reading, since pooled magnification
association alone would make that claim unsafe.

We therefore frame the contribution as a clustering-objective-trained,
biologically validated phenotyping pipeline rather than an architectural win in
the abstract: architecture drives biological agreement; the training objective
drives separability.

## Limitations

Single-centre cohort (≈196 specimens); magnification correlates with treatment
in the cohort, which is why the stratified analysis is primary, not
supplementary. No geometric/colour augmentation was used in the reported runs.
Pathologist scoring of cluster montages is exported with a structured scoring template but outstanding at submission; this work reports enrichment statistics and plainly labels expert validation as a limitation.
A frozen ImageNet encoder baseline is reported (§III-F); full SimCLR/BYOL/VAE training through the identical eval path is left to an extended benchmark, alongside multi-centre validation and stain-normalisation ablations. Test-embedding extraction is run-to-run nondeterministic at fixed weights (~14% of mean embedding norm between repeats; cluster metrics stay in band) — the likely source is nondeterministic forward kernels, still unlocalised. The DEC objective, while improving separability on the evaluated bottleneck representation, is unstable in its own 128-d latent space across seeds (latent Silhouette 0.03–0.36, treatment-AMI 0.20–0.38): centroid initialisation sensitivity in DEC-style training is a real phenomenon in our hands and is reported rather than tuned away.

# V. Conclusion

On a leak-free, confound-controlled benchmark, a deep-clustering objective on
a true latent bottleneck makes an attention/KAN autoencoder produce
well-separated liver-histopathology phenotypes that track treatment and diet
and survive a magnification confound control. In the frozen 3-seed table the full model matches or nominally exceeds the plain autoencoder on external agreement (treatment-AMI 0.433 vs 0.420) with comparable internal indices, and the comparison is reported with corrected significance tests rather than single-run claims.

# References

[1] J. Pallua, A. Brunner, B. Zelger, M. Schirmer, and J. Haybaeck, "The future of pathology is digital," Pathology - Research and Practice, vol. 216, no. 9, p. 153040, 2020, doi: 10.1016/j.prp.2020.153040.

[2] S. Al-Janabi, A. Huisman, and P. J. Van Diest, "Digital pathology: current status and future perspectives," Histopathology, vol. 61, no. 1, pp. 1-9, 2012, doi: 10.1111/j.1365-2559.2011.03814.x.

[3] M. N. Gurcan, L. E. Boucheron, A. Can, A. Madabhushi, N. M. Rajpoot, and B. Yener, "Histopathological image analysis: A review," IEEE Reviews in Biomedical Engineering, vol. 2, pp. 147-171, 2009, doi: 10.1109/RBME.2009.2034865.

[4] J. M. Bueno-de Mesquita, D. Nuyten, J. Wesseling, H. Van Tinteren, S. Linn, and M. van De Vijver, "The impact of inter-observer variation in pathological assessment of node-negative breast cancer on clinical risk assessment and patient selection for adjuvant systemic treatment," Annals of Oncology, vol. 21, no. 1, pp. 40-47, 2010, doi: 10.1093/annonc/mdp273.

[5] M. Veta, J. P. Pluim, P. J. Van Diest, and M. A. Viergever, "Breast cancer histopathology image analysis: A review," IEEE Transactions on Biomedical Engineering, vol. 61, no. 5, pp. 1400-1411, 2014, doi: 10.1109/TBME.2014.2303852.

[6] A. K. Jain, "Data clustering: 50 years beyond k-means," Pattern Recognition Letters, vol. 31, no. 8, pp. 651-666, 2010, doi: 10.1016/j.patrec.2009.09.011.

[7] G. Litjens et al., "A survey on deep learning in medical image analysis," Medical Image Analysis, vol. 42, pp. 60-88, 2017, doi: 10.1016/j.media.2017.07.005.

[8] B. C. Koenig, S. Kim, and S. Deng, "KAN-ODEs: Kolmogorov-Arnold network ordinary differential equations for learning dynamical systems and hidden physics," Computer Methods in Applied Mechanics and Engineering, vol. 432, p. 117397, 2024, doi: 10.1016/j.cma.2024.117397.

[9] S. Somvanshi, S. A. Javed, M. M. Islam, D. Pandit, and S. Das, "A survey on Kolmogorov-Arnold network," ACM Computing Surveys, vol. 58, no. 2, pp. 1-35, 2025, doi: 10.1145/3743128.

[10] Q. Wang, B. Wu, P. Zhu, P. Li, W. Zuo, and Q. Hu, "ECA-Net: Efficient channel attention for deep convolutional neural networks," in Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR), 2020, pp. 11531-11539, doi: 10.1109/CVPR42600.2020.01155.

[11] F. Wang, H. Hu, C. Shen, T. Feng, and Y. Guo, "BAM: a balanced attention mechanism to optimize single image super-resolution," Journal of Real-Time Image Processing, vol. 19, no. 5, pp. 941-955, 2022, doi: 10.1007/s11554-022-01235-x.

[12] J. Gamper, N. Alemi Koohbanani, K. Benet, A. Khuram, and N. Rajpoot, "PANNUKE: an open pan-cancer histology dataset for nuclei instance segmentation and classification," in European Congress on Digital Pathology. Springer, 2019, pp. 11-19, doi: 10.1007/978-3-030-23937-4_2.

[13] S. Vijh, P. Gaurav, and H. M. Pandey, "New bag-of-feature for histopathology image classification using reinforced cat swarm algorithm and weighted Gaussian mixture modelling," Complex & Intelligent Systems, vol. 8, no. 6, pp. 5027-5046, 2022, doi: 10.1007/s40747-022-00726-5.

[14] M. I. Rumman, N. Ono, K. Ohuchida, M. Altaf-Ul-Amin, M. Huang, and S. Kanaya, "Information maximization-based clustering of histopathology images using deep learning," PLOS Digital Health, vol. 2, no. 12, p. e0000391, 2023, doi: 10.1371/journal.pdig.0000391.

[15] H. Qu, C. D. Minacapelli, C. Tait, K. Gupta, A. Bhurwal, C. Catalano, R. Dafalla, D. Metaxas, and V. K. Rustgi, "Training of computational algorithms to predict NAFLD activity score and fibrosis stage from liver histopathology slides," Computer Methods and Programs in Biomedicine, vol. 207, p. 106153, 2021, doi: 10.1016/j.cmpb.2021.106153.

[16] B. Liu et al., "Self-supervised learning reveals clinically relevant histomorphological patterns for therapeutic strategies in colon cancer," Nature Communications, vol. 16, no. 1, p. 2328, 2025, doi: 10.1038/s41467-025-57541-y.

[17] L. Trottier, P. Giguere, and B. Chaib-Draa, "Parametric exponential linear unit for deep convolutional neural networks," in 2017 16th IEEE International Conference on Machine Learning and Applications (ICMLA). IEEE, 2017, pp. 207-214, doi: 10.1109/ICMLA.2017.00038.

[18] A. M. Ikotun, A. E. Ezugwu, L. Abualigah, B. Abuhaija, and J. Heming, "K-means clustering algorithms: A comprehensive review, variants analysis, and advances in the era of big data," Information Sciences, vol. 622, pp. 178-210, 2023, doi: 10.1016/j.ins.2022.11.139.

[19] V. Rohilla, M. S. S. Kumar, S. Chakraborty, and M. S. Singh, "Data clustering using bisecting k-means," in 2019 International Conference on Computing, Communication, and Intelligent Systems (ICCCIS), 2019, pp. 80-83, doi: 10.1109/ICCCIS48478.2019.8974537.

[20] M. Gogebakan, "A novel approach for Gaussian mixture model clustering based on soft computing method," IEEE Access, vol. 9, pp. 159987-160003, 2021, doi: 10.1109/ACCESS.2021.3130066.

[21] M. M. Fard, T. Thonet, and E. Gaussier, "Deep k-Means: Jointly clustering with k-Means and learning representations," Pattern Recognition Letters, vol. 138, pp. 185-192, 2020, doi: 10.1016/j.patrec.2020.07.028.

[22] S. Motamed, P. Rogalla, and F. Khalvati, "Data augmentation using Generative Adversarial Networks (GANs) for GAN-based detection of Pneumonia and COVID-19 in chest X-ray images," Informatics in Medicine Unlocked, vol. 27, p. 100779, 2021, doi: 10.1016/j.imu.2021.100779.

[23] J. van der Laak, G. Litjens, and F. Ciompi, "Deep learning in histopathology: the path to the clinic," Nature Medicine, vol. 27, no. 5, pp. 775-784, 2021, doi: 10.1038/s41591-021-01343-4.

[24] C. L. Srinidhi, O. Ciga, and A. L. Martel, "Deep neural network models for computational histopathology: A survey," Medical Image Analysis, vol. 67, p. 101813, 2021, doi: 10.1016/j.media.2020.101813.

[25] M.-H. Guo, T.-X. Xu, J.-J. Liu, Z.-N. Liu, P.-T. Jiang, T.-J. Mu, S.-H. Zhang, R. R. Martin, M.-M. Cheng, and S.-M. Hu, "Attention mechanisms in computer vision: A survey," Computational Visual Media, vol. 8, no. 3, pp. 331-368, 2022, doi: 10.1007/s41095-022-0271-y.

[26] H. E. Kim, A. Cosa-Linan, N. Santhanam, M. Jannesari, M. E. Maros, and T. Ganslandt, "Transfer learning for medical image classification: a literature review," BMC Medical Imaging, vol. 22, p. 69, 2022, doi: 10.1186/s12880-022-00793-7.

[27] F. Heinemann, P. Gross, S. Zeveleva, H. S. Qian, J. Hill, A. Höfer, D. Jonigk, A. M. Diehl, M. Abdelmalek, M. C. Lenter, S. S. Pullen, P. Guarnieri, and B. Stierstorfer, "Deep learning-based quantification of NAFLD/NASH progression in human liver biopsies," Scientific Reports, vol. 12, p. 19236, 2022, doi: 10.1038/s41598-022-23905-3.

[28] R. J. Chen, T. Ding, M. Y. Lu, D. F. K. Williamson, G. Jaume, A. H. Song, B. Chen, A. Zhang, D. Shao, M. Shaban, and F. Mahmood, "Towards a general-purpose foundation model for computational pathology," Nature Medicine, vol. 30, no. 3, pp. 850-862, 2024, doi: 10.1038/s41591-024-02857-3.

[29] C. Li, X. Liu, W. Li, C. Wang, H. Liu, Y. Liu, Z. Chen, and Y. Yuan, "U-KAN makes strong backbone for medical image segmentation and generation," Proceedings of the AAAI Conference on Artificial Intelligence, vol. 39, no. 5, pp. 4652-4660, 2025, doi: 10.1609/aaai.v39i5.32491.

[30] A. M. Ikotun, F. Habyarimana, and A. E. Ezugwu, "Cluster validity indices for automatic clustering: A comprehensive review," Heliyon, vol. 11, no. 2, p. e41953, 2025, doi: 10.1016/j.heliyon.2025.e41953.

[31] J. Xie, R. Girshick, and A. Farhadi, "Unsupervised deep embedding for clustering analysis," in Proc. 33rd Int. Conf. Machine Learning (ICML), 2016, pp. 478–487.

[32] X. Guo, L. Gao, X. Liu, and J. Yin, "Improved deep embedded clustering with local structure preservation," in Proc. 26th Int. Joint Conf. Artificial Intelligence (IJCAI), 2017, pp. 1753–1759.

[33] T. Chen, S. Kornblith, M. Norouzi, and G. Hinton, "A simple framework for contrastive learning of visual representations," in Proc. 37th Int. Conf. Machine Learning (ICML), 2020, pp. 1597–1607.

[34] J.-B. Grill et al., "Bootstrap your own latent: A new approach to self-supervised learning," in Advances in Neural Information Processing Systems (NeurIPS), vol. 33, 2020, pp. 21271–21284.

[35] X. Wang et al., "TransPath: Transformer-based self-supervised learning for histopathological image classification," in Proc. Medical Image Computing and Computer Assisted Intervention (MICCAI), LNCS vol. 13432, Springer, 2022.


[36] M. Y. Lu et al., "A visual-language foundation model for computational pathology," Nature Medicine, vol. 30, pp. 863–874, 2024.

[37] E. Vorontsov et al., "A foundation model for clinical-grade computational pathology and rare cancers detection," Nature Medicine, vol. 30, pp. 2924–2935, 2024.

[38] H. Xu et al., "A whole-slide foundation model for digital pathology from real-world data," Nature, vol. 630, pp. 181–188, 2024.

**Acknowledgment—** This research was funded by Universitas Brawijaya through the grant program "Applied Research and Artificial Intelligence Development in 2024" under contract number [00067.10/UN10.A0507/B/KS/2024].
